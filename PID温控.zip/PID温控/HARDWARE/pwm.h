#ifndef __PWM_H
#define __PWM_H

#include "sys.h"

void TIM14_PWM_Init(u32 arr,u32 psc);

#endif

